# SERVER_URL = 'http://localhost:8080'
# CLIENT_URL = 'http://localhost:3000'
SERVER_URL = ' https://api.graphix-ai.io'
CLIENT_URL = 'https://app.graphix-ai.io'
